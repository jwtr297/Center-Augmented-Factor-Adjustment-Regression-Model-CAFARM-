#' @import prclust
sim <- function(Run_time,data_type,n,p,r,epsilon){
  set.seed(297)

  res_1 <- matrix(0,Run_time,6)
  res_2 <- matrix(0,Run_time,6)
  res_3 <- matrix(0,Run_time,4)
  res_4 <- matrix(0,Run_time,5)

  ###
  alpha0 <- Intercept_alpha(data_type,n)
  beta0 <- c(runif(5,0.8,1),rep(0,(p-5)))
  ###

  for(s in 1:Run_time){
    data_sim <- Cov_fac(n,p,r,beta0,alpha0)
    Fhat <- data_sim[[1]]
    Fm <- data_sim[[2]]
    Uhat <- data_sim[[3]]
    X <- data_sim[[4]]
    Xaug <- data_sim[[5]]
    Y <- data_sim[[6]]
    B <- data_sim[[7]]

    #BIC
    para_CPFP <- BIC_PFP(Y,Fhat,Uhat,epsilon)
    para_CAR <- BIC_CAFARM(Y,Fhat,Uhat,epsilon)
    para_Oracle <- BIC_Oracle_fac(Fhat,Uhat,Y,alpha0)
    para_SCAR <- BIC_SCAR(X,Y,epsilon)

    #Estimation
    est_FARMCPFP <- FA_PFP(Fhat,Uhat,Y,1,para_CPFP[2],3,0.1,para_CPFP[1],epsilon)
    est_CAFARM <- CAFARM(Y,Xaug,r,para_CAR[3],para_CAR[2],0.1,para_CAR[1],epsilon)
    est_Oracle_fac <- Oracle_fac(Y,alpha0,Fhat,Uhat,para_Oracle)
    est_SCAR <- SCAR(Y,X,para_SCAR[3],para_SCAR[2],0.1,para_SCAR[1],epsilon)

    #indexes_CPFP
    res_1[s,1] <- EVMSE(est_FARMCPFP[[1]],alpha0)#alpha
    res_1[s,2] <-  EVMSE(est_FARMCPFP[[3]],beta0)#beta
    res_1[s,3] <- CM(est_FARMCPFP[[3]],beta0)[1]#TPR
    res_1[s,4] <- CM(est_FARMCPFP[[3]],beta0)[2]#TNR
    G_stru <- G(est_FARMCPFP[[4]])[[2]]
    res_1[s,5] <- clusterStat(G_stru,alpha0)[[1]]#RI
    res_1[s,6] <- G(est_FARMCPFP[[4]])[[1]]#Group number

    #indexes_CAR
    res_2[s,1] <- EVMSE(est_CAFARM[[1]],alpha0)
    res_2[s,2] <-  EVMSE(est_CAFARM[[4]],beta0)
    res_2[s,3] <- CM(est_CAFARM[[4]],beta0)[1]
    res_2[s,4] <- CM(est_CAFARM[[4]],beta0)[2]
    res_2[s,5] <- clusterStat(est_CAFARM[[2]],alpha0)[[1]]
    res_2[s,6] <- para_CAR[[1]]

    #indexes_Oracle_fac
    res_3[s,1] <- EVMSE(est_Oracle_fac[[2]],alpha0)
    res_3[s,2] <- EVMSE(est_Oracle_fac[[4]],beta0)
    res_3[s,3] <- CM(est_Oracle_fac[[4]],beta0)[1]
    res_3[s,4] <- CM(est_Oracle_fac[[4]],beta0)[2]

    #indexes_SCAR
    res_4[s,1] <- EVMSE(est_SCAR[[1]],alpha0)
    res_4[s,2] <- EVMSE(est_SCAR[[3]],beta0)
    res_4[s,3] <- CM(est_SCAR[[3]],beta0)[1]
    res_4[s,4] <- CM(est_SCAR[[3]],beta0)[2]
    res_4[s,5] <- clusterStat(est_SCAR[[2]],alpha0)[[1]]
    #print current iteration index
    print(s)
  }
  return(list(res_1,res_2,res_3,res_4))
}

