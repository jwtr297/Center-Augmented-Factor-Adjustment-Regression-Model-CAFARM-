GK<-function(Y,Fhat,Uhat,n,p,r,epsilon){
  GKs<-c(rep(0,4))
  Xaug <- cbind(Fhat,Uhat)
  r <- ncol(Fhat)
  for(i in 2:5){
    R <- CAFARM(Y,Xaug,r,5,0.001,0.1,i,epsilon)
    gamma <- unlist(R[2])
    theta1 <- unlist(R[3])
    beta <- unlist(R[4])
    Yhat <- gamma+ Fhat%*%theta1+ Uhat%*%beta
    S <- sum(beta!=0)
    GKs[i-1] <- log(sum((Y-Yhat)^2)/n)+2*log(n*i+p)*(S+i)*log(n)/n
  }
  return(which.min(GKs)+1)
} #BIC of Group number for FARMCAR


#' Selecting Tuning Parameter for CAFARM via corresponding BIC
#'
#' This function is to select tuning parameters simultaneously for CAFARM via minimizing the BIC.
#'
#' @param Y The response vector.
#' @param Fhat The estimated common factors matrix.
#' @param Uhat The estimated idiosyncratic factors matrix.
#' @param epsilon The user-supplied stopping tolerance.
#' @author Yong He, Liu Dong, Fuxin Wang, Mingjuan Zhang.
#' @export
#' @examples
#' n <- 50
#' p <- 50
#' r <- 3
#' alpha <- sample(c(-3,3),n,replace=TRUE,prob=c(1/2,1/2))
#' beta <- c(rep(1,2),rep(0,48))
#' B <- matrix((rnorm(p*r,1,1)),p,r)
#' F_1 <- matrix((rnorm(n*r,0,1)),n,r)
#' U <- matrix(rnorm(p*n,0,0.1),n,p)
#' X <- F_1%*%t(B)+U
#' Y <- alpha + X%*%beta + rnorm(n,0,0.5)
#' BIC_CAFARM(Y,F_1,U,0.3)
BIC_CAFARM <- function(Y,Fhat,Uhat,epsilon){
  n <- nrow(Fhat)
  p <- ncol(Uhat)
  r <- ncol(Fhat)
  Xaug <- cbind(Fhat,Uhat)
  K <- GK(Y,Fhat,Uhat,n,p,r,epsilon)
  GCVs<-matrix(0,10,10)
  for(j in 1:10){
    for(k in 1:10){
      Lasso <- (sqrt(log(p)/n)*10^(seq(-1,0.5,length.out=10)[j]))
      CAR <- seq(0.001,0.1,length.out=10)[k]
      res <- CAFARM(Y,Xaug,r,CAR,Lasso,0.1,K,epsilon)
      gamma <- unlist(res[2])
      theta1 <- res[[3]]
      beta <- unlist(res[4])
      Yhat <- gamma + Fhat%*% theta1+ Uhat%*%beta
      GCVs[j,k]<- sum((Y-Yhat)^2)/(n-length(unique(beta[beta!=0])))^2
      print(c(j,k))
    }
  }
  min_positions <- which(GCVs == min(GCVs), arr.ind = TRUE)
  min_row <- min(min_positions[, 1])
  min_col <- min(min_positions[, 2])
  lasso <- sqrt(log(p)/n)*10^(seq(-1,0.5,length.out=10)[min_row])
  CAR <- seq(0.001,0.1,length.out=10)[min_col]
  return(c(K,lasso,CAR))
}




G <- function(eta){
  K <- 1
  n <- ncol(eta)
  g1 <- c(rep(0,n))
  group <- list(c(1))
  etasym <- matrix(0,n,n)
  for(s in 1:(n-1)){
    for(l in (s+1):n){
      etasym[l,s] <- eta[s,l]
      etasym[s,l] <- eta[s,l]
    }
  }

  for (s in 2:n){
    for(i in 1:K){
      if (min(abs(etasym[group[[i]],s]))==0){
        group[[i]] <- c(group[[i]],s)
      }
    }
    if (min(abs(etasym[unlist(group),s]))>0){
      group <- append(group,c(s))
    }
    K <- length(group)
  }

  for (m in 1:K){
    g1[group[[m]]] <- m
  }

  return(list(K,g1))
}




#' Selecting Tuning Parameter for FA-PFP via corresponding BIC
#'
#' This function is to select tuning parameters simultaneously for FA-PFP via minimizing the BIC.
#'
#' @param Y The response vector.
#' @param Fhat The estimated common factors matrix.
#' @param Uhat The estimated idiosyncratic factors matrix.
#' @param epsilon The user-supplied stopping tolerance.
#' @author Yong He, Liu Dong, Fuxin Wang, Mingjuan Zhang.
#' @export
#' @examples
#' n <- 50
#' p <- 50
#' r <- 3
#' alpha <- sample(c(-3,3),n,replace=TRUE,prob=c(1/2,1/2))
#' beta <- c(rep(1,2),rep(0,48))
#' B <- matrix((rnorm(p*r,1,1)),p,r)
#' F_1 <- matrix((rnorm(n*r,0,1)),n,r)
#' U <- matrix(rnorm(p*n,0,0.1),n,p)
#' X <- F_1%*%t(B)+U
#' Y <- alpha + X%*%beta + rnorm(n,0,0.5)
#' BIC_PFP(Y,F_1,U,0.3)
BIC_PFP <- function(Y,Fhat,Uhat,epsilon){
  n <- nrow(Fhat)
  p <- ncol(Uhat)
  BICs <- matrix(0,10,10)
  for(j in 1:10){
    for(k in 1:10){
      Lasso <- (sqrt(log(p)/n)*10^(seq(-1,0,length.out=10)[j]))
      lam <- seq(0.3,0.8,length.out=10)[k]
      res <- FA_PFP(Y,Fhat,Uhat,1,lam,3,0.1,Lasso,epsilon)
      alpha_hat <- res[[1]]
      theta_hat <- res[[2]]
      eta <- res[[4]]
      beta_hat <- res[[3]]
      Yhat <- alpha_hat + Fhat%*%theta_hat + Uhat%*%beta_hat
      S <-sum(abs(beta_hat)>0)
      g <- G(eta)[[1]]
      BICs[j,k]<-log(sum((Y-Yhat)^2)/n)+2*log(n*g+p)*(S+g)*log(n)/n
      print(c(j,k))
    }
  }
  min_positions <- which(BICs == min(BICs), arr.ind = TRUE)
  min_row <- min(min_positions[, 1])
  min_col <- min(min_positions[, 2])
  results <- c(min_row ,min_col)
  lasso <- sqrt(log(p)/n)*10^(seq(-1,0,length.out=10)[results[1]])
  lambda <- seq(0.3,0.8,length.out=10)[results[2]]
  return(c(lasso,lambda))
}




Omega <- function(alpha){
  n <- length(alpha)
  O <- matrix(0,n,length(unique(alpha)))
  for (i in (1:length(unique(alpha)))){
    O[,i] <- as.numeric(alpha==(unique(alpha)[i]))
  }
  return(O)
}




BIC_Oracle_fac<-function(Fhat,Uhat,Y,alpha){
  n<-nrow(Fhat)
  p <- ncol(Uhat)
  GCVs<-c()
  for(j in 1:10){
    Lasso <- (sqrt(log(p)/n)*10^(seq(-2,0,length.out=10)[j]))
    R <- Oracle_fac(Y,alpha,Fhat,Uhat,Lasso)
    gamma <- R[[2]]
    theta <- R[[3]]
    beta <- R[[4]]
    Yhat <- gamma + Fhat%*%theta+ Uhat%*%beta
    GCVs[j] <- sum((Y-Yhat)^2)/(n-length(unique(beta[beta!=0])))^2
  }
  min_positions <- min(which(GCVs == min(GCVs)))
  lasso <- sqrt(log(p)/n)*10^(seq(-2,0,length.out=10)[min_positions])
  return(lasso)
}




GK_SCAR<-function(Y,X,n,p,epsilon){
  GKs<-c(rep(0,4))
  for(i in 2:5){
    R <- SCAR(Y,X,5,0.001,0.1,i,epsilon)
    gamma <- unlist(R[1])
    theta1 <- unlist(R[2])
    beta <- unlist(R[3])
    Yhat <- gamma+ X%*%beta
    S <- sum(beta!=0)
    GKs[i-1] <- log(sum((Y-Yhat)^2)/n)+2*log(n*i+p)*(S+i)*log(n)/n
  }
  return(which.min(GKs)+1)
}




BIC_SCAR <- function(X,Y,epsilon){
  n <- nrow(X)
  p <- ncol(X)
  K <- GK_SCAR(Y,X,n,p)
  GCVs<-matrix(0,10,10)
  for(j in 1:10){
    for(k in 1:10){
      Lasso <- (sqrt(log(p)/n)*10^(seq(-1,0.5,length.out=10)[j]))
      CAR <- seq(0.001,0.1,length.out=10)[k]
      R <- SCAR(Y,X,CAR,Lasso,0.1,K,epsilon)
      gamma <- unlist(R[2])
      beta <- unlist(R[3])
      Yhat <- gamma + X%*%beta
      GCVs[j,k]<- sum((Y-Yhat)^2)/(n-length(unique(beta[beta!=0])))^2
      print(c(j,k))
    }
  }
  min_positions <- which(GCVs == min(GCVs), arr.ind = TRUE)
  min_row <- min(min_positions[, 1])
  min_col <- min(min_positions[, 2])
  lasso <- (sqrt(log(p)/n)*10^(seq(-1,0.5,length.out=10)[min_row]))
  CAR <- seq(0.001,0.1,length.out=10)[min_col]
  return(c(K,lasso,CAR))
}


